#!/bin/sh
python3 count.py
