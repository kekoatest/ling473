#!/bin/sh
python3 tally.py
