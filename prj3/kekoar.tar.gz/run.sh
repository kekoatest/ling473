#!/bin/sh
export PYTHONIOENCODING=utf-8
/bin/python3.4 fsm.py
