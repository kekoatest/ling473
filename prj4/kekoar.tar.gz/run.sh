#!/bin/sh
python3 dna.py
